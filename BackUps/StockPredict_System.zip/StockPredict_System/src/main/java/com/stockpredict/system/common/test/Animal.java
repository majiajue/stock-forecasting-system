package com.stockpredict.system.common.test;

/**
 * @author wangzhewen
 * @time 2022/3/26 22:28
 */
public interface Animal {

    /**
     * Eat the provided plant.
     *
     * @param
     */
    void howl();
}
