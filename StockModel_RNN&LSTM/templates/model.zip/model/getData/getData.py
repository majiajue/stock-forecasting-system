import datetime

import pandas as pd
import tushare as ts

ts.set_token('0552d7adcfe8c321bd512ea8e7ff66c69375a9aeeb567fbfc7440cd4')

# 初始化pro接口
pro = ts.pro_api()
df1 = pro.daily(ts_code='000001.SZ, 000002.SZ', end_date='20211201')
# , start_date='202001101'

# 'ts_code', 'trade_date', 'open', 'high', 'low', 'close', 'pre_close':昨日收盘价, 'change':涨跌额, 'pct_chg':	涨跌幅,未复权, 'vol':成交量, 'amount':成交金额（元 CNY）
print(type(df1))
print([column for column in df1])
print(df1.shape)

