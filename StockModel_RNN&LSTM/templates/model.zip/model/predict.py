import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.python.keras.models import load_model

if __name__ == '__main__':

    data = pd.read_csv('./data/GOOG.csv', date_parser=True)
    data_training = data[data['Date'] < '2019-01-01'].copy()
    data_training = data_training.drop(['Date', 'Adj Close'], axis=1)

    data_test = data[data['Date'] >= '2019-01-01'].copy()
    data_test = data_test.drop(['Date', 'Adj Close'], axis=1)

    scaler = MinMaxScaler()
    scaler.fit_transform(data_training)

    past_60_days = data_training.tail(60)
    df = past_60_days.append(data_test, ignore_index=True)
    inputs = scaler.transform(df)

    X_test = []
    y_test = []
    for i in range(60, inputs.shape[0]):
        X_test.append(inputs[i - 60:i])
        y_test.append(inputs[i, 0])
    X_test, y_test = np.array(X_test), np.array(y_test)

    open_tranform_rate = scaler.scale_[0]
    scale = 1 / open_tranform_rate

    model = load_model("./model/stock_model")
    y_pred = model.predict(X_test)
    y_pred = y_pred * scale
    y_test = y_test * scale

    plt.figure(figsize=(14, 5))
    plt.plot(y_test, color='red', label='Real Google Stock Price')
    plt.plot(y_pred, color='blue', label='Predicted Google Stock Price')
    plt.title('Google Stock Price Prediction')
    plt.xlabel('Time')
    plt.ylabel('Google Stock Price')
    plt.legend()
    plt.show()
